function nyisdKi() {
    let menu = document.getElementById("opcio");
    menu.style.display = "block";
    
    let hambigomb = document.getElementById("hambi");
    //hambigomb.style.backgroundColor = "blue";
    hambigomb.style.display = "none";
}

function csukdBe() {
    let menu = document.getElementById("opcio");
    menu.style.display = "none";
    
    let hambigomb = document.getElementById("hambi");
    //hambigomb.style.backgroundColor = "blue";
    hambigomb.style.display = "block";
}